import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAIv2ZshF8FLj57-3VnQ_UIZWNAjoDBeA0',
    appId: '1:372919017140:web:ef6d4bea585984f66781e1',
    messagingSenderId: '372919017140',
    projectId: 'food-app-3ea29',
    authDomain: 'food-app-3ea29.firebaseapp.com',
    storageBucket: 'food-app-3ea29.appspot.com',
    databaseURL: 'https://food-app-3ea29-default-rtdb.firebaseio.com/'
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyD36oKJDWW8_l6zz9Wi1NKay0XGTDlawg0',
    appId: '1:372919017140:android:6b0343a09fc4ea346781e1',
    messagingSenderId: '372919017140',
    projectId: 'food-app-3ea29',
    storageBucket: 'food-app-3ea29.appspot.com',
      databaseURL: 'https://food-app-3ea29-default-rtdb.firebaseio.com/'
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCN_Qx-6y-k5l3zyWV_quR133Ym-x_nkxY',
    appId: '1:372919017140:ios:866bfd4576714dad6781e1',
    messagingSenderId: '372919017140',
    projectId: 'food-app-3ea29',
    storageBucket: 'food-app-3ea29.apps pot.com',
    iosBundleId: 'com.example.foodApp',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyCN_Qx-6y-k5l3zyWV_quR133Ym-x_nkxY',
    appId: '1:372919017140:ios:866bfd4576714dad6781e1',
    messagingSenderId: '372919017140',
    projectId: 'food-app-3ea29',
    storageBucket: 'food-app-3ea29.apps pot.com',
    iosBundleId: 'com.example.foodApp',
  );
}
