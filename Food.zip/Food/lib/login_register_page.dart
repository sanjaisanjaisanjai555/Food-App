import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'main.dart'; // Make sure this is imported

class LoginRegisterPage extends StatefulWidget {
  const LoginRegisterPage({Key? key}) : super(key: key);

  @override
  _LoginRegisterPageState createState() => _LoginRegisterPageState();
}

class _LoginRegisterPageState extends State<LoginRegisterPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login/Register'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextFormField(
              controller: _surnameController,
              decoration: const InputDecoration(labelText: 'Surname'),
            ),
            TextFormField(
              controller: _phoneNumberController,
              decoration: const InputDecoration(labelText: 'Phone Number'),
            ),
            TextFormField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextFormField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _saveUserProfile();
              },
              child: const Text('Register/Login'),
            ),
          ],
        ),
      ),
    );
  }

  void _saveUserProfile() {
    // Get values from text controllers
    String name = _nameController.text;
    String surname = _surnameController.text;
    String phoneNumber = _phoneNumberController.text;
    String email = _emailController.text;
    String password = _passwordController.text;

    // Create a UserProfile object
    UserProfile userProfile = UserProfile(
      name: name,
      surname: surname,
      phoneNumber: phoneNumber,
      email: email,
      password: password,
    );

    // Save user profile to Firebase
    _saveToFirebase(userProfile);
  }

  void _saveToFirebase(UserProfile userProfile) {
    // Convert UserProfile to a map
    final userMap = {
      'name': userProfile.name,
      'surname': userProfile.surname,
      'phoneNumber': userProfile.phoneNumber,
      'email': userProfile.email,
      'password': userProfile.password,
    };

    // Save to Firebase (assuming 'users' is the collection you want to save to)
    FirebaseDatabase.instance
        .ref()
        .child('users')
        .child('123') // Change this logic to use unique IDs
        .set(userMap)
        .then((_) {
      // After saving, navigate to HomePage
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginRegisterPage()),
      );
    }).catchError((error) {
      // Handle errors if any
      print("Error saving user profile: $error");
    });
  }
}
