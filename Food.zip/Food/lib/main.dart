import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:food_app/notify.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'firebase_options.dart';
import 'package:food_app/login_register_page.dart';
import 'package:food_app/widget_tree.dart';


class UserProfile {
  String? name;
  String? surname;
  String? phoneNumber;
  String? email;
  String? password;

  UserProfile({
    this.name,
    this.surname,
    this.phoneNumber,
    this.email,
    this.password,
  });

}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  NotificationService().initNotification();
  tz.initializeTimeZones();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food Management App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Colors.blue,
      ),
      home:  home(),
    );
  }
}

class LoginApp extends StatelessWidget {
  const LoginApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login Page',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),

    );
  }
}

class FoodItem {
  String? name;
  int quantity;
  DateTime? placementTime;
  DateTime reminderTime;

  FoodItem(
      {this.name,
      required this.quantity,
      this.placementTime,
      required this.reminderTime});
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final List<FoodItem> _foodItems = [];
  final TextEditingController _itemNameController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Food Management '),
        backgroundColor: Colors.green,
        actions: [
          PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'numberoftimealert') {
                _handleNumberOfTimeAlert();
              } else if (value == 'aboutus') {
                // Handle about us action
              }
            },
            itemBuilder: (BuildContext context) {
              return {'Number of Time Alert', 'About Us'}.map((String choice) {
                return PopupMenuItem<String>(
                  value: choice.toLowerCase().replaceAll(' ', ''),
                  child: Text(choice),
                );
              }).toList();
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Add Food Item',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _itemNameController,
              decoration: const InputDecoration(labelText: 'Item Name'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _quantityController,
              decoration: const InputDecoration(labelText: 'Quantity'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _addItem,
              child: const Text('Add Item'),
            ),
            const SizedBox(height: 32),
            const Text(
              'Food Items',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Column(
              children: _foodItems.map((foodItem) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            FoodDetailsScreen(foodItem: foodItem),
                      ),
                    );
                  },
                  child: Card(
                    child: ListTile(
                      title: Text(foodItem.name ?? ''),
                      subtitle: Text('Quantity: ${foodItem.quantity}'),
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: const EdgeInsets.all(0),
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.green,
              ),
              child: UserAccountsDrawerHeader(
                decoration: BoxDecoration(color: Colors.green),
                accountName: Text(
                  "Aravindhan P",
                  style: TextStyle(fontSize: 18),
                ),
                accountEmail: Text("aravindhan4722@gmail.com"),
                currentAccountPictureSize: Size.square(50),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Color.fromARGB(255, 165, 255, 137),
                  child: Text(
                    "A",
                    style: TextStyle(fontSize: 30.0, color: Colors.blue),
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person),
              title: const Text(' My Profile '),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const UserProfilePage()),
                  );
              },
            ),
            ListTile(
              leading: const Icon(Icons.book),
              title: const Text(' My Course '),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.workspace_premium),
              title: const Text(' Go Premium '),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.video_label),
              title: const Text(' Saved Videos '),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit),
              title: const Text(' Edit Profile '),
              onTap: () {
                Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const UserProfilePage()),
              );
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('LogOut'),
              onTap: () {
                _showExitConfirmationDialog(); // Show confirmation dialog before logging out
              },
            ),
          ],
        ),
      ),
    );
  }

  void _handleNumberOfTimeAlert() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const AlertStatisticsPage()),
    );
  }

  void _addItem() {
    setState(() {
      String name = _itemNameController.text;
      int quantity = int.tryParse(_quantityController.text) ?? 0;

      if (name.isNotEmpty && quantity > 0) {
        _foodItems.add(FoodItem(
          name: name,
          quantity: quantity,
          reminderTime:
              DateTime.now(), // You can set the reminder time as needed
        ));
        _itemNameController.clear();
        _quantityController.clear();
      }
    });
  }

  void _showExitConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Exit Confirmation'),
          content: const Text('Are you sure you want to exit?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
              },
              child: const Text('No'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
                _performLogout(); // Perform logout actions here
              },
              child: const Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  void _performLogout() {
    // Perform logout actions here
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginApp()),
      (route) => false,
    );
  }
}

class FoodDetailsScreen extends StatefulWidget {
  final FoodItem foodItem;

  const FoodDetailsScreen({super.key, required this.foodItem});

  @override
  _FoodDetailsScreenState createState() => _FoodDetailsScreenState();
}

class _FoodDetailsScreenState extends State<FoodDetailsScreen> {
  late DateTime _placementTime = DateTime.now();
  late DateTime _reminderTime = DateTime.now();
  bool _detailsSaved = false; // Track if details are saved
  late DatabaseReference ref;

  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    // TODO: implement initState
    FirebaseDatabase database = FirebaseDatabase.instance;
    ref = FirebaseDatabase.instance.ref("users/123");
    super.initState();
  }

  //Function for the data saving process
  Future<void> saveData() async {
    //food name
    //quantitiy
    //placement time
    //remainder time
    ref.child('${widget.foodItem.name}').set({
      'quantity': '${widget.foodItem.quantity}',
      'place_time': '$_placementTime',
      'remainder_time': '${widget.foodItem.reminderTime}'
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Food Details'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Food Item: ${widget.foodItem.name}',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            const Text('Enter Placement Details:'),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: _placementTime,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2101),
                );
                if (picked != null && picked != _placementTime) {
                  setState(() {
                    _placementTime = picked;
                  });
                }
              },
              child: Text(
                  'Select Date: ${_placementTime.toString().substring(0, 10)}'),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () async {
                final TimeOfDay? picked = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.fromDateTime(_placementTime),
                );
                if (picked != null) {
                  setState(() {
                    _placementTime = DateTime(
                      _placementTime.year,
                      _placementTime.month,
                      _placementTime.day,
                      picked.hour,
                      picked.minute,
                    );
                  });
                }
              },
              child: Text(
                  'Select Time: ${_placementTime.toString().substring(
                      11, 16)}'),
            ),
            const SizedBox(height: 16),
            const Text('Enter Reminder Details:'),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () async {
                final DateTime? picked = await showDatePicker(
                  context: context,
                  initialDate: _reminderTime,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(2101),
                );
                if (picked != null && picked != _reminderTime) {
                  setState(() {
                    _reminderTime = picked;
                  });
                }
              },
              child: Text(
                  'Select Date: ${_reminderTime.toString().substring(0, 10)}'),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () async {
                final TimeOfDay? picked = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay.fromDateTime(_reminderTime),
                );
                if (picked != null) {
                  setState(() {
                    _reminderTime = DateTime(
                      _reminderTime.year,
                      _reminderTime.month,
                      _reminderTime.day,
                      picked.hour,
                      picked.minute,
                    );
                  });
                }
              },
              child: Text(
                  'Select Time: ${_reminderTime.toString().substring(11, 16)}'),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                print(_reminderTime.runtimeType);
                setState(() {
                  _scheduleNotification(_reminderTime);
                  saveData();
                  // NotificationService().scheduleNotification(
                  //     title: 'Scheduled Notification',
                  //     body: '$_reminderTime',
                  //     scheduledNotificationDateTime: _reminderTime);
                  _detailsSaved = true; // Mark details as saved
                });
                _showSavedMessage(context); // Show saved message
              },
              child: const Text('Save'),
            ),
            if (_detailsSaved) // Display saved details if saved
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 32),
                  const Text(
                    'Placement Details:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text('Date: ${_placementTime.toString().substring(0, 10)}'),
                  Text('Time: ${_placementTime.toString().substring(11, 16)}'),
                  const SizedBox(height: 16),
                  const Text(
                    'Reminder Details:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text('Date: ${_reminderTime.toString().substring(0, 10)}'),
                  Text('Time: ${_reminderTime.toString().substring(11, 16)}'),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _scheduleNotification(DateTime scheduledTime) async {
    // Initialize the plugin
    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

    // Initialize settings for Android
    final AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    // Initialize settings for both platforms
    final InitializationSettings initializationSettings = InitializationSettings(
      android: initializationSettingsAndroid
    );

    // Initialize the plugin with settings
    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,

    );

    // Define notification details
    final AndroidNotificationDetails androidPlatformChannelSpecifics =
    AndroidNotificationDetails(
      'your channel id', // Channel ID
      'your channel name', // Channel Name
      importance: Importance.max,
      priority: Priority.high,
    );

    final NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    // Schedule the notification
    await flutterLocalNotificationsPlugin.zonedSchedule(
      0, // Notification ID
      'Scheduled Notification', // Notification title
      'This is a scheduled notification', // Notification body
      _nextInstanceOfOneMinuteAfterNow(), // Scheduled time
      platformChannelSpecifics,
      uiLocalNotificationDateInterpretation:
      UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  tz.TZDateTime _nextInstanceOfOneMinuteAfterNow() {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);

    // Add 1 minute to the current time
    tz.TZDateTime scheduledDate = now.add(const Duration(seconds: 30));

    return scheduledDate;
  }

}

void _showSavedMessage(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Success'),
        content: const Text('Item saved successfully!'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(); // Dismiss the dialog
            },
            child: const Text('OK'),
          ),
        ],
      );
    },
  );
}

class AlertStatisticsPage extends StatefulWidget {
  const AlertStatisticsPage({super.key});

  @override
  _AlertStatisticsPageState createState() => _AlertStatisticsPageState();
}

class _AlertStatisticsPageState extends State<AlertStatisticsPage> {
  int numberOfAlerts = 0;
  int correctlyStopped = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alert Statistics'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Number of Alerts: $numberOfAlerts',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 16),
            Text(
              'Correctly Stopped: $correctlyStopped',
              style: const TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}

class UserProfilePage extends StatefulWidget {
  const UserProfilePage({Key? key}) : super(key: key);

  @override
  _UserProfilePageState createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextFormField(
              controller: _surnameController,
              decoration: const InputDecoration(labelText: 'Surname'),
            ),
            TextFormField(
              controller: _phoneNumberController,
              decoration: const InputDecoration(labelText: 'Phone Number'),
            ),
            TextFormField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextFormField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _saveUserProfile();
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _saveUserProfile() {
    // Get values from text controllers
    String name = _nameController.text;
    String surname = _surnameController.text;
    String phoneNumber = _phoneNumberController.text;
    String email = _emailController.text;
    String password = _passwordController.text;

    // Create a UserProfile object
    UserProfile userProfile = UserProfile(
      name: name,
      surname: surname,
      phoneNumber: phoneNumber,
      email: email,
      password: password,
    );

    // Save user profile to Firebase (you can implement this logic)
    _saveToFirebase(userProfile);
  }

  void _saveToFirebase(UserProfile userProfile) {

    FirebaseDatabase.instance.ref().child('users').child('123').set(userProfile as Map<String,dynamic>);
  }
}
